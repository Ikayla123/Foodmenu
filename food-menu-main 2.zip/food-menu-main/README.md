<<<<<<< HEAD
# food-menu
Pinoy kusina is a filipino dishes with a local menu. 
=======


## Introduction

Welcome to our Food Ordering Web Application! This project is a responsive, user-friendly website designed a food showcase website. It features a modern, attractive design with a focus on showcasing the local filipino food.

Key features include:

- Responsive design for various screen sizes
- Interactive food menu with filtering options
- User-friendly navigation


This project is a responsive food showcase website. Users can browse the menu, filter items by category, show description, and benefits of the food. The site is designed to be user-friendly on both desktop and mobile devices, making it easy for customers to order food from anywhere.
>>>>>>> 6c5b7c2 (Initial commit)
